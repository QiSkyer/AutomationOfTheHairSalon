﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kurs
{
    class DataStore
    {
        public static string Userlogin;
        public static string MasterName;
        public static string MasterFam;
        public static string MasterOtch;
    }
    class Reg1Data
    {
        public static int Clientid = -1;
        public static string ClientName;
        public static string ClientFamily;
        public static string ClientOtchstvo;
        public static string ClientPhone;
        public static string ServiceId;
        public static string Service;
        public static string ServiceCost;
    }
    class Reg2Data
    {
        public static string Date;
        public static string masterid;
        public static string master;
        public static string Time;
    }
}
